/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmlapplication;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.Circle;
import static javafxmlapplication.Utils.*;

/**
 *
 * @author jsoler
 */
public class FXMLDocumentController implements Initializable {
    private Label labelMessage;
    @FXML
    private Circle Circle;
    @FXML
    private GridPane gridPane;
    private double dragStartX;
    private double dragStartY;
    
    // you must initialize here all related with the object 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }
    private int rowCount =5;
    private int columCount = 5;
    
    private int normalize(int num,int limit){
        return (num+limit)%limit;
    }
    @FXML
    public void handleMouseClicked(MouseEvent event){
    
    double x = event.getSceneX();
    double y = event.getSceneY();
    int col = columnCalc(gridPane,x);
     int row= rowCalc(gridPane,y);
     GridPane.setColumnIndex(Circle, col);
     GridPane.setRowIndex(Circle, row);
    
    
    
    }
    @FXML
    public void handleKeyPressed(KeyEvent event) {
        if (event.getCode() == KeyCode.UP) {
            System.out.println("moving up");
            int row = GridPane.getRowIndex(Circle);
            int newRow = normalize(row - 1, rowCount);
            GridPane.setRowIndex(Circle, newRow);

        }
         if (event.getCode() == KeyCode.DOWN) {
            System.out.println("moving down");
            int row = GridPane.getRowIndex(Circle);
            int newRow = normalize(row + 1, rowCount);
            GridPane.setRowIndex(Circle, newRow);

        }
         if (event.getCode() == KeyCode.RIGHT) {
            System.out.println("moving right");
            int col = GridPane.getColumnIndex(Circle);
            int newCol = normalize(col + 1, columCount);
            GridPane.setColumnIndex(Circle, newCol);
    }
             if (event.getCode() == KeyCode.LEFT) {
            System.out.println("moving left");
            int col = GridPane.getColumnIndex(Circle);
            int newCol = normalize(col - 1, columCount);
            GridPane.setColumnIndex(Circle, newCol);
        }
           
    }

    @FXML
    private void handleMouseDraggedBall(MouseEvent event) {
    double newX = event.getSceneX() - dragStartX;
    double newY = event.getSceneY() - dragStartY;

    Circle.setTranslateX(newX);
    Circle.setTranslateY(newY);
    }

    @FXML
    private void handleMousePressedBall(MouseEvent event) {
    
    dragStartX = event.getSceneX() ;
    dragStartY = event.getSceneY();
    }

    @FXML
    private void handleMouseReleasedBall(MouseEvent event) {
       
        // Importante: resetear LayoutX y LayoutY
        Circle.setTranslateX(0);
        Circle.setTranslateY(0);
        
        event.consume();
    }

    
    }

    
   
    

