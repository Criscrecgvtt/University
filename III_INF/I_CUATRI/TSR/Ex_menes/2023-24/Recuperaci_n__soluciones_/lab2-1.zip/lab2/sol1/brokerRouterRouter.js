const {zmq, lineaOrdenes, traza, error, adios, creaPuntoConexion} =  require('../tsr')
lineaOrdenes("frontendPort backendPort")
let workers  =[] // workers disponibles
let pendiente=[] // peticiones no enviadas a ningún worker
let w2c=[]
let frontend = zmq.socket('router')
let backend  = zmq.socket('router')
creaPuntoConexion(frontend, frontendPort)
creaPuntoConexion(backend,  backendPort)

function procesaPeticion(cliente,sep,msg) { 
	traza('procesaPeticion','cliente sep msg',[cliente,sep,msg])
	if (workers.length) {
		w = workers.shift()
		backend.send([w,'','4','',msg])
		w2c[w]=cliente
	}
	else pendiente.push([cliente,msg])
}
function procesaMsgWorker(worker,sep1,cliente,sep2,resp) {
	traza('procesaMsgWorker','worker sep1 cliente sep2 resp', 
                            [worker, sep1, cliente, sep2, resp])
	if (pendiente.length) { 
		let [c,m] = pendiente.shift()
		backend.send([worker,'', '4','',m])
		w2c[worker]=c	
	}
	else workers.push(worker) 
	if (w2c[worker]) frontend.send([w2c[worker],'',resp])
}
frontend.on('message', procesaPeticion)
frontend.on('error'  , (msg) => {error(`${msg}`)})
 backend.on('message', procesaMsgWorker)
 backend.on('error'  , (msg) => {error(`${msg}`)})
 process.on('SIGINT' , adios([frontend, backend],"abortado con CTRL-C"))
