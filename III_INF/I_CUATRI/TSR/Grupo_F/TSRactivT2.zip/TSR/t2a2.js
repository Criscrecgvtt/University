const {EventEmitter} = require('events')
const emisor = new EventEmitter()

let n1 = 0                 // Para evento 1: contador
let n2 = 0, ms2 = 2000, t2 // Para evento 2: contador, repetir cada ms2, temporizador t2

function f2() {
	if (++n2 >= n1) console.log("Evento dos",n2)
	else console.log("Hay más eventos de tipo 1")
}

function f3() {
	console.log("evento tres",ms2)
	if (ms2 < 18000) {
		ms2 *= 3
		clearInterval(t2)
		t2 = setInterval(emite("dos"), ms2)
	}
}

function emite(evento) { return ()=>emisor.emit(evento) }

emisor.on("uno", () => { n1++; console.log("Evento uno",n1) })
emisor.on("dos",  f2)
emisor.on("tres", f3)

     setInterval(emite("uno"), 3000)
t2 = setInterval(emite("dos"), ms2)
     setInterval(emite("tres"), 10000)
