const ev = require('events')
const emitter = new ev.EventEmitter
const e1 = "print"
const e2 = "read"
const books = [ "Walk Me Home", "When I Found You", "Jane's Melody", "Pulse" ]

// Function that creates the intended event listeners.
function createListener( eventName ) {
    let num = 0
    return function (arg) {
        let book = ""
        if (arg)
            book = ", now with book title '" + arg + "',"
        console.log("Event " + eventName + book + " has happened " + ++num + " times.")
    }
}

// Listeners are registered in the event emitter.
emitter.on(e1, createListener(e1))
emitter.on(e2, createListener(e2))
emitter.on(e1, () => console.log("Something has been printed!!"))

function emitE2() {
    let counter=0
    return function () {
        // This second argument provides the argument for the "e2" listener.
        emitter.emit(e2,books[counter++ % books.length])
    }
}

setInterval( () => emitter.emit(e1), 2000 ) // First event generated every 2 seconds
setInterval( emitE2(), 3000 ) // Second event generated every 3 seconds
