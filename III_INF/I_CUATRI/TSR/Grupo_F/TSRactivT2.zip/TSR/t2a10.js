const fs = require('fs')
const fsp= require('fs').promises

function ordena(txt) {return txt.toString().split('\n').sort().join('\n')}

function etapa1(f) {
	fs.writeFileSync(f+".sorted1", ordena(fs.readFileSync(f)))
	console.log('fin etapa 1')
}

function etapa2(f) {
	fs.writeFile(f+".sorted2", ordena(fs.readFileSync(f)), () => 
	    console.log('fin etapa 2'))
}

function etapa3(f) {
	fs.readFile(f, (err, data) => {
		if (err) console.error(err)
		else {
			fs.writeFile(f+".sorted3", ordena(data), () => 
			    console.log('fin etapa 3'))
		}
	})
}

function etapa4(f1,f2) {
	let quedan = 2
	fs.readFile(f1, cb(f1))
	fs.readFile(f2, cb(f2))
	
	function cb(fichero) {
		return (err, data) => {
			if (err) console.error(err)
			else {
				fs.writeFile(fichero+".sorted4", ordena(data), () => {
					console.log("final fichero "+fichero)
					if (--quedan == 0) console.log("fin etapa 4")
				})
			}
		}
	}
}

function etapa5(...ficheros) {
	let quedan = ficheros.length
	for (f of ficheros) fs.readFile(f, cb(f))

	function cb(fichero) {
		return (err, data) => {
			if (err) console.error(err)
			else {
				fs.writeFile(fichero+".sorted5", ordena(data), () => {
					console.log("final fichero "+fichero)
					if (--quedan == 0) console.log("fin etapa 5")
				})
			}
		}
	}
}

function etapa5p(...ficheros) {
	let end = []
	for (f of ficheros) end.push(procesa(f))
	Promise.all(end).then(() => console.log("fin etapa 5 con promesas"))

	function procesa(fichero) {
		return fsp.readFile(fichero).then(data => {
			return fsp.writeFile(fichero+".sorted5p", ordena(data))
			       .then(()=>console.log("final fichero "+fichero))
		})
	}
}

// etapa1("t2a10.js")
// etapa2("t2a10.js")
// etapa3("t2a10.js")
// etapa4("t2a10.js", "xml.r")
// etapa5("t2a10.js", "xml.r", "worker.js")
etapa5p("t2a10.js", "xml.r", "worker.js")
