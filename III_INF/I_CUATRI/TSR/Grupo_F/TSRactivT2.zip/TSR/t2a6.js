const fs = require('fs')
const fsp= require('fs').promises
const fichero = process.argv.slice(2)

function conCallbacks() {
	let quedan = fichero.length, tallaMax = 0, mayor=""

	for (let f of fichero)
		fs.readFile(f, cb(f))
		
	function cb(nombreFichero) {
		return (err,data) => {
			if (err) console.error(err)
			else {
				let n = data.length
				if (n > tallaMax) {tallaMax = n; mayor = nombreFichero}
				if (--quedan == 0)
					console.log( `El fichero más grande es ${mayor}, con ${tallaMax} bytes`)
			}
		}
	}
}

function conPromesas() {
	let datos = []
	for (let f of fichero)
		datos.push(fsp.readFile(f))
		
	Promise.all(datos)
	.then(txt => txt.map(x=>x.length))
	.then(talla => {
		let tallaMax = 0, mayor = ""
		for (let i in fichero)
			if (talla[i] > tallaMax) {tallaMax = talla[i]; mayor = fichero[i]}
		console.log( `El fichero más grande es ${mayor}, con ${tallaMax} bytes`)
	})
}

conCallbacks()
conPromesas()
