En la primera sessió ens familiaritzarem amb l'entorn de treball i alguns
conjunts de dades, començant per iris.
