En la primera sesión nos familiarizaremos con el entorno de trabajo y algunos
conjuntos de datos, empezando por iris.
